/**
 * Created by florent on 11/02/16.
 */
public class Product {

    int id;
    int weight;

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", weight=" + weight +
                '}';
    }
}
