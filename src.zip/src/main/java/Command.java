/**
 * Created by florent on 11/02/16.
 */
public class Command {

    int droneId;


    public Command(int droneId) {
        this.droneId = droneId;
    }
}
